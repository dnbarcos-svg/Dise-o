PAGINA WEB PERSONAL - DANIELA NICOLE BARCO SANUNGA

Archivo principal: index.html

Para publicarla en GitHub Pages:
1. Crea un repositorio nuevo en GitHub.
2. Sube el archivo index.html (o todos los archivos de esta carpeta).
3. En el repositorio, entra a Settings > Pages.
4. En Build and deployment, selecciona Deploy from a branch.
5. Selecciona la rama main y la carpeta / (root), y guarda.
6. Espera a que GitHub Pages genere el enlace de tu sitio.

La música y el video están incrustados dentro de index.html. La fotografía se carga desde internet, por lo que necesita conexión.
